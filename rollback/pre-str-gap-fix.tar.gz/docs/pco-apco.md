# PCO/APCO Handling

VectorCore ePDG supports optional Protocol Configuration Options (PCO) and Additional Protocol Configuration Options (APCO) on S2b GTPv2-C.

This is deliberately conservative:

- S2b Create Session may include PCO/APCO request containers only when configured.
- S2b Create Session Response PCO/APCO is parsed and stored when present.
- Unknown containers are preserved as opaque values and logged.
- PCO/APCO absence never fails attach.
- Opaque NAS-style PCO is not sent over SWu.

Known container IDs are from 3GPP TS 24.008 table 10.5.154 and are carried as GTPv2-C PCO/APCO IEs per 3GPP TS 29.274:

| Container | ID |
| --- | --- |
| P-CSCF IPv6 Address | `0x0001` |
| DNS Server IPv6 Address | `0x0003` |
| P-CSCF IPv4 Address | `0x000c` |
| DNS Server IPv4 Address | `0x000d` |
| IPv4 Link MTU | `0x0010` |

IPv4 DNS, P-CSCF IPv4, and P-CSCF IPv6 addresses are delivered to the UE via IKEv2 CFG_REPLY using the standard configuration attributes: `INTERNAL_IP4_DNS` (DNS), `P_CSCF_IP4_ADDRESS` (RFC 7651), and `P_CSCF_IP6_ADDRESS` (RFC 7651). MTU is stored and logged; no access-side delivery mechanism is currently implemented.
