# Handover vs. Full Detach: STR and S2b Teardown Gap

## Background

When a UE silently disconnects or sends a clean DELETE, the IKE-initiated teardown path
(`fullTeardown`) now sends a Diameter STR (Session-Termination-Request) to the AAA/HSS
on the SWm interface. However, there is a second teardown path — PGW-initiated — that
does not send STR, and the two cases must be handled differently.

---

## Two Teardown Paths

### Path 1 — IKE-initiated (UE DELETE or DPD timeout)
`fullTeardown` in `internal/ikev2/inform.go`  
→ tears down XFRM + GTP-U + S2b + session  
→ **sends STR** with `Termination-Cause = 1 (DIAMETER_LOGOUT)`  ✓

### Path 2 — PGW-initiated (handover or network-side detach)
`handlePGWDelete` in `cmd/epdg/main.go` → `cleanupSession`  
→ tears down GTP-U, optionally S2b  
→ **no STR sent** — correct for handover, but wrong for full detach

---

## The Problem: Handover vs. Full Detach Look the Same

Both arrive on the same `handlePGWDelete` / `cleanupSession` code path. The only signal
that distinguishes them is the **HI (Handover Indication) bit** inside the GTPv2-C
Indication IE of the incoming Delete Session Request (TS 29.274 Table 8.12-2, octet 3 bit 1).

Currently, the S2b layer does not parse this IE at all:

- `ieIndication` is **not defined** in `internal/s2b/codec.go`
- `handleDeleteSessionRequest` in `internal/s2b/client.go` reads no IEs from the request body
- `DeleteSessionEvent` struct carries no handover flag

---

## What 3GPP Specs Require

**TS 23.402 §8.6** — Handover from untrusted WLAN to 3GPP:  
The PGW sends Delete Session Request on S2b *after* the LTE bearer is already established.
The UE is still live — same PGW, same PDN, same IP — just changing access network.

**TS 29.273 §6.2.2.1** — SWm STR:  
The ePDG shall send STR when the PDN connection terminates. The `Termination-Cause` AVP
distinguishes the reason:

| Value | Name | When to use |
|-------|------|-------------|
| 1 | DIAMETER_LOGOUT | Subscriber fully disconnected |
| 8 | DIAMETER_USER_MOVED | Subscriber moved to another access (handover) |

Sending `DIAMETER_LOGOUT` during a handover risks causing the AAA to deregister the
subscriber from non-3GPP access prematurely, which can block re-authentication if the UE
moves back to WiFi before the stale record expires.

---

## What Needs to Be Done

### 1. Parse the Indication IE in `internal/s2b/codec.go`

Add the IE type constant:
```go
ieIndication uint8 = 77  // TS 29.274 §8.12
```

Extract the HI bit (octet 3, bit 1) from the Indication IE in `handleDeleteSessionRequest`.

### 2. Carry the flag in `DeleteSessionEvent` (`internal/s2b/client.go`)

```go
type DeleteSessionEvent struct {
    LocalControlTEID uint32
    Sequence         uint32
    Peer             string
    IsHandover       bool  // HI bit from Indication IE
}
```

### 3. Branch in `handlePGWDelete` (`cmd/epdg/main.go`)

```
if !event.IsHandover:
    send STR with Termination-Cause = DIAMETER_LOGOUT (1)
if event.IsHandover:
    send STR with Termination-Cause = DIAMETER_USER_MOVED (8)
    — OR — skip STR entirely (spec is ambiguous; verify with live HSS)
```

The STR call should follow the same pattern as in `fullTeardown`: 3-second timeout,
log error but don't block cleanup. The session `SWMSessionID` is available on the
`session.Session` object.

---

## Current Risk Assessment

| Scenario | STR sent? | Correct? |
|----------|-----------|----------|
| UE sends IKE DELETE | Yes, LOGOUT | ✓ |
| DPD timeout (silent disconnect) | Yes, LOGOUT | ✓ |
| PGW Delete Session — full detach | No | ✗ gap |
| PGW Delete Session — WiFi→LTE handover | No | ✓ (safe for now) |

The gap (full detach from PGW with no STR) means the AAA/HSS is not notified when
the PGW tears down the session from the network side. In practice, the HSS cleans up
on its own eventually, but it can cause "already authenticated" rejections on reconnect
until the stale record expires.

---

## References

- 3GPP TS 23.402 §8.6 — Handover from Untrusted Non-3GPP to 3GPP
- 3GPP TS 29.273 §6.2.2.1 — STR/STA on SWm
- 3GPP TS 29.274 §8.12 — Indication IE, Table 8.12-2 (HI bit: octet 3, bit 1)
- `internal/s2b/client.go:773` — `handleDeleteSessionRequest` (no IE parsing today)
- `internal/s2b/codec.go:32` — IE type constants (no `ieIndication`)
- `cmd/epdg/main.go:183` — `handlePGWDelete`
- `internal/ikev2/inform.go:111` — `fullTeardown` (sends STR today)
