# VectorCore ePDG Protocol Scope

VectorCore ePDG is a production-grade ePDG implemented as a single self-contained Go binary. It provides untrusted non-3GPP access to the Evolved Packet Core for VoWiFi using a native Go IKEv2 engine.

## Interfaces

| Interface | Role | Standard |
|-----------|------|----------|
| SWu | UE ↔ ePDG IPsec tunnel | RFC 7296 (IKEv2), RFC 4187 (EAP-AKA), RFC 4303 (ESP), RFC 3948 (NAT-T) |
| SWm | ePDG ↔ AAA EAP-AKA proxy | 3GPP TS 29.273 |
| S2b | ePDG ↔ PGW PDN session control | 3GPP TS 29.274 |
| GTP-U | ePDG ↔ PGW user-plane | 3GPP TS 29.281 |

## Capabilities

- Native Go IKEv2 engine: IKE_SA_INIT, IKE_AUTH, CHILD SA, DH key exchange, NAT-T, rekey, reauthentication, DPD
- EAP-AKA authentication proxied over SWm Diameter to AAA/HSS
- Linux XFRM netlink for kernel IPsec SA and policy installation; ESP-in-UDP for NAT traversal
- S2b GTPv2-C: Create/Delete Session, Create/Delete/Update Bearer
- Userspace GTP-U dataplane over UDP/2152 with Linux TUN interface and nfqueue uplink capture
- Dedicated bearer support with TFT uplink packet selection
- PCO/APCO: DNS, P-CSCF, and MTU decoded from S2b and delivered to the UE via IKEv2 CFG_REPLY
- Full session lifecycle: IKE SA delete, CHILD SA delete, DPD, PGW-initiated delete, reauthentication
