#!/bin/bash
# Run this once on a new host after cloning the repo.
# Copies project memory into the Claude Code memory directory for this working path.
set -e
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
MEMORY_SRC="$PROJECT_DIR/.claude/memory"
MEMORY_DST="$HOME/.claude/projects/$(echo "$PROJECT_DIR" | tr '/' '-' | sed 's/^-//')/memory"
mkdir -p "$MEMORY_DST"
cp "$MEMORY_SRC"/*.md "$MEMORY_DST/"
echo "Memory restored to $MEMORY_DST"
