---
name: project-state
description: Native Go IKEv2 ePDG architecture, current implementation phase, key decisions, and what was in progress when context was saved.
metadata:
  type: project
---

## Architecture decision: native Go IKEv2 replacing strongSwan

strongSwan + IPC plugin has been fully replaced with a native Go IKEv2/IPsec server.
The binary is now fully self-contained with no external IPC dependencies.

**Why:** Eliminate the strongSwan plugin IPC boundary, reduce operational complexity,
gain full control over IKEv2 state machine for EAP-AKA integration.

**Archived working copy:** `/usr/src/vectorcore-epdg.userspace-GTP-U` — DO NOT TOUCH.
No backwards compatibility required.

## Packages

| Package | Status | Notes |
|---------|--------|-------|
| `internal/ikev2` | Phase 1 complete | IKE_SA_INIT handler, crypto, proposal negotiation |
| `internal/xfrm` | Not started | Kernel IPsec SA/policy programming (Phase 3) |
| `internal/swm` | Carried over | SWm Diameter client — wire to IKE_AUTH in Phase 2 |
| `internal/s2b` | Carried over | GTPv2-C S2b client — wire after CHILD_SA in Phase 4 |
| `internal/gtpu` | Carried over | Userspace GTP-U dataplane |
| `internal/session` | Carried over | Session state manager |
| `internal/config` | Updated | Added IKEv2Config struct and ikev2: yaml section |
| `internal/ipc` | Obsolete | Mark for deletion |

## Crypto suite (from production swanctl config `vectorcore-epdg-ims`)

IKE proposals (preference order):
1. aes256-sha256-prfsha256-modp2048
2. aes256-sha256-prfsha256-modp3072
3. aes256-sha512-prfsha512-modp2048
4. aes256-sha512-prfsha512-modp3072
5. aes128-sha1-prfsha1-modp2048

ESP proposals (same enc+integ with PFS DH, no AES-GCM):
aes256-sha256-modp2048, aes256-sha256-modp3072, aes256-sha512-modp2048,
aes256-sha512-modp3072, aes128-sha1-modp2048

Key transform IDs:
- DH_2048_BIT_MODP = 14, DH_3072_BIT_MODP = 15
- PRF_HMAC_SHA1 = 2, PRF_HMAC_SHA2_256 = 5, PRF_HMAC_SHA2_512 = 7 (defined locally)
- AUTH_HMAC_SHA1_96 = 2, AUTH_HMAC_SHA2_256_128 = 12, AUTH_HMAC_SHA2_512_256 = 14 (defined locally)
- ENCR_AES_CBC = 12

## Dependencies

- `github.com/free5gc/ike v1.2.1` — used for `message` package (parse/encode) ONLY.
  Security interfaces use unexported `getAttribute()` — cannot extend from outside.
  All crypto is implemented in `internal/ikev2/crypto.go`.

## Phase roadmap

- **Phase 1** (IKE_SA_INIT) — COMPLETE. Build passes. Needs test on VM with TUN.
- **Phase 2** (IKE_AUTH + EAP-AKA) — IDi/IDr parsing, NAI→IMSI, swm wire-up, MSK→AUTH, CFG_REPLY
- **Phase 3** (XFRM) — `internal/xfrm`, kernel IPsec SA/policy programming after CHILD_SA
- **Phase 4** (S2b + GTP-U) — wire s2b CreateSession after CHILD_SA established
- **Phase 5** (Lifecycle) — DPD, delete, rekey, cleanup
- **Phase 6** (Hardening) — multiple proposals, certs, MOBIKE

## Testing

- **SWu-IKEv2** at `/usr/src/SWu-IKEv2/swu_emulator.py` — Python UE simulator.
  Phase 1/2 testing: use `-d <epdg_ip> -I <imsi> -M <mcc> -N <mnc> -a <apn>`.
- Phase 1+2 testable on local host (no PGW needed).
- Phase 4+ needs PGW (Cisco StarOS qvpc-si v21.28.0, build 87076).

## Dev environment

- **LXC → VM migration in progress.** LXC lacks `/dev/net/tun`; moving to KVM/QEMU VM on PVE.
  Need TUN for GTP-U dataplane, and will need kernel xfrm for Phase 3.
- Primary working directory: `/usr/src/vectorcore-epdg`
- Build: `go build -buildvcs=false ./...`

## strongSwan reference

- Plugin at `/usr/src/strongswan-epdg/src/libcharon/plugins/vectorcore_eap_proxy/`
- Hook sequence: IDi→NAI, IDr→APN, SPI pair→session_id; initiate()→AUTH_START;
  process()→AUTH_CONTINUE; on SUCCESS: store PAA+DNS+P-CSCF; release_address()→SESSION_DELETED
- IMSI extraction from NAI: starts with '0', strip it, take ≤15 digits
- Session ID format: `{spi_i:016x}-{spi_r:016x}`
