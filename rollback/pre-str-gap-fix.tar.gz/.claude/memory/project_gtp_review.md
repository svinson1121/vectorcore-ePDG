---
name: project-gtp-review
description: GTP code review findings and correction plan for vectorcore-epdg. 15 non-conformances found against TS 29.274 and TS 29.281.
metadata:
  type: project
---

GTP review completed 2026-06-11. 15 issues found across GTP-U (dataplane.go/nfqueue.go) and GTPv2-C (s2b/client.go + codec.go).

**Why:** Userspace GTP was built to support QoS/TFT features the kernel GTP module lacks. The custom implementation has several spec gaps and implementation bugs.

**Critical bugs (fix before production):**
- GU-1: `injectRawIPv4()` creates a new raw socket per downlink packet — FD exhaustion under load (dataplane.go:795)
- GC-1: S2b TEID seeds from `time.Now().UnixNano()` — predictable, should use crypto/rand like AllocateTEID() (client.go:187)

**High spec violations:**
- GU-2: Uplink always uses default bearer; TFT filters stored but never applied (dataplane.go:634)
- GU-3: PAA mismatch on downlink logs warning but still forwards packet (dataplane.go:726)
- GU-4: Uplink sends to `m.cfg.GTP.LocalPort` on PGW — should use fixed 2152/config.GTPUPort (dataplane.go:657)
- GU-5: No active Echo Requests to PGW — path failure undetectable (TS 29.281 §7.2.1)
- GU-7: IPv4-only PAA; no IPv6/dual-stack (TS 23.402 §4.2.2)
- GC-3: No GTPv2-C request retransmission (T3-RESPONSE/N3-REQUESTS missing per TS 29.274 §6.1.2)
- GC-5: No Update Bearer Request (type 97) handler; PGW transactions time out (TS 29.274 §7.3.1)

**Medium violations:**
- GC-2: Sequence number max is 0x7FFFFF, should be 0xFFFFFF per TS 29.274 §6.1.2 (codec.go:26)
  ✅ FIXED. Config gate implemented. CONFIRMED CISCO STAROS BUG: StarOS qvpc-si rejects any CSR
  where bit 23 of the 24-bit sequence field is set. WORKAROUND: `max_sequence: 8388607` under
  `gtp:` in epdg.yaml caps at 0x7FFFFF. This is a StarOS defect — spec allows up to 0xFFFFFF.

- GC-CBR: Create Bearer Response — FULLY RESOLVED 2026-06-12. S2b dedicated bearer establishment
  working end-to-end with Cisco StarOS qvpc-si v21.28.0 (build 87076). Both dedicated bearers
  (EBI=6, EBI=7) established and active; ping to P-CSCF confirmed; clean session teardown verified.

  Final fix summary:
  1. `create_bearer_fteid_instance: 8` in epdg.yaml (TS 29.274 Table 7.2.4-2: S2b-U ePDG F-TEID at instance=8)
  2. PGW echo at instance=9 (S2b-U PGW F-TEID, hardcoded in client.go)
  3. QoS IE removed from CBR response bearer context (Cisco ePDG admin guide §16c)
  4. Charging ID echoed from each request BC into corresponding response BC
  5. `create_bearer_max_contexts: 2` in epdg.yaml (StarOS sends 2 BCs)
  6. All response Bearer Context IEs at instance=0 (StarOS qvpc-si rejects any BC at instance≠0
     in CBR response, despite sending both request BCs at instance=0 itself — non-standard but
     required for interop). client.go:1281.

  REMAINING: GU-2 — uplink TFT selection not applied; all uplink uses default bearer (EBI=5)
  regardless of dedicated bearer TFT. Downlink is PGW-driven and uses dedicated bearers correctly.

- GC-CBR-HISTORY: StarOS 21.28.0 sends PGW GTP-U TEID at instance=4 / iface=33 in Create Bearer
  Request BC. Also sends Charging ID (IE type 94) inside each BC — e.g. 0x010005C1 for bearer 1.
  StarOS uses Charging ID to correlate CBR response BCs back to request BCs. Missing Charging ID
  causes "Conditional IE missing: SGW Data TEID (Bearer Context)" regardless of F-TEID instance.
  ROOT CAUSE confirmed via pcap /tmp/cbr.pcap 2026-06-12.

- GC-4: GTPv2-C Echo Response doesn't mirror T-flag from request (client.go:747)
- GU-6: No End Marker message for handover (TS 29.281 §7.3.7)
- X-1: nativeEndian hardcoded to LittleEndian in nfqueue.go:173

**Low/future:**
- GC-6: CSR missing conditional IEs (ULI, Indication flags)
- X-2: Length guard asymmetry between encodeTPDU and encodePathMessage

**How to apply:** When touching GTP code, prioritize GU-1 first (risk of service outage), then
GU-2 (QoS broken for dedicated bearers), then GC-3/GC-5 (interop with PGWs that use
retransmission/Update Bearer).
