---
name: user-prefs
description: Standing instructions and working style preferences from the user. Apply these in every session.
metadata:
  type: feedback
---

**No speculative code changes.**
Rule: Do not make code changes until there is a confirmed, diagnosed issue. No guessing, no pre-emptive fixes.
Why: Wastes time and money chasing phantom problems.
How to apply: Diagnose first (read logs, grep code, reproduce). Only write code once the root cause is certain.

**Config defaults belong in epdg.yaml, NOT in Go Default() functions.**
Rule: If a config value has a sensible default, put it in epdg.yaml. The Go Default() function is a last-resort fallback only.
Why: User explicitly corrected this — YAML is the source of truth for operators.
How to apply: When adding new config fields, add the default value to configs/epdg.yaml, not to the Default() struct literal in config.go.

**No doc updates during active architecture changes.**
Rule: Don't update protocol-scope.md, project-plan.md or similar docs while the codebase is in heavy flux.
Why: Too much is changing; docs would be stale before they're written.
How to apply: Defer doc updates until a phase is fully stable and tested.

**EAP-AKA only (not EAP-AKA').**
Rule: ePDG uses EAP-AKA (RFC 4187). TWAG uses EAP-AKA'. Don't conflate them.
How to apply: When implementing Phase 2 IKE_AUTH, implement EAP-AKA only.

**swm/s2b/gtpu packages: "what we have now is working."**
Rule: Don't refactor or change these packages beyond what's strictly needed for IKEv2 integration.
Why: They work in production. Risk of regression is not worth cleanup.
How to apply: Wire new interfaces to them; leave internals alone unless a confirmed bug requires a fix.
