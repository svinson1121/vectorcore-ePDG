# Memory Index

- [GTP Review Findings](project_gtp_review.md) — 15 non-conformances in GTP-U + GTPv2-C against TS 29.274/29.281; includes fix priority order
- [Project State](project_state.md) — Native Go IKEv2 ePDG architecture, current phase, and key decisions
- [User Preferences](user_prefs.md) — Working style, code conventions, and standing instructions
