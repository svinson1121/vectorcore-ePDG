package ikev2

// IKE SA state.

import (
	"math/big"
	"net"
	"sync"
	"time"
)

type ikeState int

const (
	ikeStateInit ikeState = iota
	ikeStateAuth
	ikeStateEstablished
	ikeStateDeleting
)

// ikeSA holds per-IKE-SA state from IKE_SA_INIT through lifetime.
type ikeSA struct {
	mu sync.Mutex

	// SPIs
	spiI uint64
	spiR uint64

	// Remote endpoint (may change on NAT-T migration)
	remoteAddr *net.UDPAddr
	// True when both IKE and ESP traffic use port 4500 (NAT detected).
	natT bool

	// Nonces
	nonceI []byte
	nonceR []byte

	// Negotiated crypto
	proposal *negotiatedProposal
	saKey    *ikeSAKey

	// DH state
	dhPriv *big.Int
	dhPub  []byte // our public value sent in KE response

	// Raw IKE_SA_INIT messages (needed for AUTH payload computation).
	initReqRaw  []byte
	initRespRaw []byte

	state     ikeState
	createdAt time.Time
	lastSeen  time.Time

	// DPD (Dead Peer Detection) state for ePDG-initiated probes.
	ourMsgID  uint32    // counter for INFORMATIONAL requests we send (under mu)
	dpdMsgID  uint32    // message ID of the outstanding probe (0 = none pending)
	dpdSentAt time.Time // when the probe was sent (zero = no probe pending)

	// IKE_AUTH EAP-AKA round state (under mu).
	eapRound     int    // 0 = first IKE_AUTH not yet seen
	swmSessionID string // Diameter session ID across EAP rounds
	imsi         string
	nai          string
	apn          string
	msk          []byte // set on EAP-AKA success

	// CHILD SA state (populated in first IKE_AUTH, used in final round).
	espProp     *childProposal
	espPropNum  uint8
	peerESPSPI  uint32 // UE's inbound ESP SPI from SAi2
	localESPSPI uint32 // ePDG's inbound ESP SPI for SAr2
	cpWantsIP   bool   // UE requested INTERNAL_IP4_ADDRESS via CFG_REQUEST

	// IDi payload bytes for AUTH computation: [IDType | 0x00 | 0x00 | 0x00 | IDData].
	idiAuthBytes []byte

	sessionID string // key in session.Manager

	// localIP is the ePDG's outer IP used as the XFRM SA endpoint.
	// Derived at IKE_SA_INIT time from routing toward remoteAddr.
	localIP net.IP
}
