# VectorCore ePDG — Agent Reference

## Purpose

VectorCore ePDG is a fully self-contained Go binary implementing the VoWiFi control plane and userspace datapath. It replaces the previous strongSwan + IPC architecture. There is no IPC socket, no external IKEv2 daemon, and no Unix socket between internal packages.

```text
UE / phone
   |
SWu: IKEv2 + EAP-AKA + IPsec  (native Go — no strongSwan)
   |
VectorCore ePDG  (single Go binary)
   |
   +-- internal/ikev2    Native Go IKEv2 engine (RFC 7296)
   +-- internal/xfrm     Linux XFRM netlink (kernel IPsec SA/policy)
   +-- internal/swm      SWm Diameter / EAP-AKA proxy
   +-- internal/s2b      S2b GTPv2-C client to PGW
   +-- internal/gtpu     Userspace GTP-U dataplane
   +-- internal/session  Session FSM and cleanup
   +-- internal/config   Configuration
   +-- internal/pco      PCO/APCO encode/decode
   +-- internal/logging  Structured logging
```

---

## Mandatory 3GPP Compliance

All protocol behavior must follow applicable 3GPP specifications.

```text
3GPP TS 23.402   Architecture for non-3GPP access to EPC.
3GPP TS 24.302   UE/ePDG behavior for SWu.
3GPP TS 29.273   SWm Diameter interface, EAP-AKA transport, keying material.
3GPP TS 29.274   S2b GTPv2-C control plane between ePDG and PGW.
3GPP TS 33.402   Security for non-3GPP access. Authentication/keying for SWu.
RFC 7296         IKEv2.
RFC 4303         ESP.
RFC 3948         UDP encapsulation of ESP (NAT-T).
RFC 4187         EAP-AKA.
```

Hard boundaries:
- ePDG/SWu uses EAP-AKA (RFC 4187). Not EAP-AKA′.
- ePDG uses SWm. Not STa.
- ePDG uses S2b. Not S2a.

---

## Package Overview

All packages are fully implemented and end-to-end validated with a real UE, real SIM EAP-AKA, live HSS, and Cisco StarOS PGW.

```text
internal/ikev2    IKEv2 state machine and packet engine.
                  Built on github.com/free5gc/ike for packet parse/encode.
                  Handles IKE_SA_INIT, IKE_AUTH + EAP-AKA, CHILD SA, rekey,
                  reauthentication, DPD, IKE SA delete, CHILD SA delete.
                  Owns UDP listeners on port 500 and 4500.

internal/xfrm     Linux XFRM netlink.
                  Installs/removes inbound and outbound kernel IPsec SAs and policies.
                  ESP-in-UDP on port 4500 when NAT is detected.

internal/swm      SWm Diameter client, EAP-AKA challenge/response proxy.
                  Connects to AAA or DRA over TCP or SCTP.
                  Handles DER/DEA, DWR/DWA, MSK and APN/AMBR extraction.

internal/s2b      S2b GTPv2-C client.
                  Create/Delete Session, Create/Delete/Update Bearer.
                  Cisco StarOS interop validated (max_sequence workaround).

internal/gtpu     Userspace GTP-U dataplane.
                  UDP/2152 socket + TUN interface (vc-gtpu0 by default).
                  Default bearer, dedicated bearers, TFT uplink selection.
                  nfqueue uplink capture with optional iptables rule install.

internal/session  Session FSM (New → IKESAInit → ... → Active → Deleted).
                  Coordinates XFRM, GTP-U, S2b, and IKE state across packages.

internal/config   Config loader and validator.
                  Simple YAML-like key:value format, section-scoped.
                  Default config path: /opt/vectorcore/etc/epdg.yaml

internal/pco      PCO/APCO encode/decode per 3GPP TS 24.008.
                  Handles DNS, P-CSCF, MTU container IDs.

internal/logging  Structured logging via slog. File + console output.
```

---

## IKEv2 Identity Extraction

```text
IDi payload   → UE NAI  e.g. 0311435123456789@wlan.mnc435.mcc311.3gppnetwork.org
IDr payload   → APN FQDN  e.g. internet.epdg.epc.mnc435.mcc311.3gppnetwork.org
IKE SPI pair  → session ID  {spi_i:016x}-{spi_r:016x}
```

IMSI extraction from NAI:
- NAI must begin with '0'
- Strip leading '0', take next up to 15 bytes
- Validate all digits

---

## IKE_AUTH EAP-AKA Flow

```text
IKE_AUTH initiate  →  swm.StartAuth(nai, imsi, apn)   →  EAP-Request/AKA-Challenge
IKE_AUTH process   →  swm.ContinueAuth(eapPayload)    →  EAP-Response or SUCCESS+MSK
On EAP SUCCESS     →  s2b.CreateSession(imsi, apn)    →  PAA + TEIDs
                   →  xfrm.InstallSA(...)              →  kernel IPsec SA + policy
                   →  CFG_REPLY with PAA, DNS, P-CSCF
IKE SA delete      →  s2b.DeleteSession()
                   →  xfrm.RemoveSA(...)
                   →  gtpu cleanup
```

---

## Crypto Suite

Real UEs negotiate these transforms — all are supported.

### IKE SA proposals

```text
aes256-sha256-prfsha256-modp2048
aes256-sha256-prfsha256-modp3072
aes256-sha512-prfsha512-modp2048
aes256-sha512-prfsha512-modp3072
aes128-sha1-prfsha1-modp2048
```

### ESP / CHILD SA proposals

```text
aes256-sha256-modp2048
aes256-sha256-modp3072
aes256-sha512-modp2048
aes256-sha512-modp3072
aes128-sha1-modp2048
```

---

## Session FSM States

```text
New → IKESAInit → IKEAuthEAP → EAPAuthenticated → S2bCreateSessionSent
  → S2bAccepted → XFRMInstalling → GTPUInstalling → Active
  → CleaningUp → Deleted
  (Failed is a terminal error state)
```

Active requires all of: EAP-AKA success + MSK, S2b accepted + PAA + PGW TEIDs, XFRM SA and policy installed, GTP-U bearer installed, CHILD SA TS narrowed to PAA.

---

## Configuration

Default config path: `/opt/vectorcore/etc/epdg.yaml`
Example config: `config/epdg.yaml`

The config uses a simple `section: / key: value` format. See `internal/config/config.go` for all keys and `internal/config/validate.go` for required fields.

The `ikev2:` section requires `cert_file`. The binary will error and exit at startup if the cert file is missing or cannot be loaded.

---

## Non-Negotiable Rules

- Do not add strongSwan, IPC sockets, or Unix domain sockets between internal packages.
- Do not use NAT to work around PAA/CHILD SA TS misalignment.
- Do not implement EAP-AKA′, STa, or S2a.
- Do not add metrics, Prometheus, or dashboards unless explicitly requested.
- Do not add comments that describe what code does — only add comments for non-obvious WHY.
- Do not make code changes to fix a suspected issue without first confirming the issue exists.
- Do not refactor or restructure working packages unless a confirmed bug exists.
- `internal/ipc` is deleted dead code — do not recreate it.
